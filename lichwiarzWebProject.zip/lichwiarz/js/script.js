const floatingMenu = document.querySelector('.floatingMenu');
const floatingMenuBack = document.querySelector('.floatingMenuBack');
const menuButtons = document.querySelector('.buttons');
const floatingAccount = document.querySelector('.floatingAccount');
const floatingAccountMenuBack = document.querySelector('.floatingAccountMenuBack');
const loginMenu = document.querySelector('.login');
function showMenuIcon(){
    if(floatingMenu.style.display=='none'){
        floatingMenuBack.style.display = 'none';
        floatingMenu.style.display = 'block';
        menuButtons.style.display = 'none';
    } else {
        floatingMenuBack.style.display = 'block';
        floatingMenu.style.display = 'none';
        menuButtons.style.display = 'flex';
    }
}
function showFloatingAccount(){
    if(floatingAccount.style.display == 'none'){
        floatingAccountMenuBack.style.display = 'none';
        floatingAccount.style.display = 'block'
        loginMenu.style.display = 'none';
    } else {
        floatingAccount.style.display = 'none';
        floatingAccountMenuBack.style.display = 'block';
        loginMenu.style.display = 'flex';
    }
}
floatingMenu.addEventListener('click',()=>{
    showMenuIcon();
    if(loginMenu.style.display == 'flex'){
        showFloatingAccount();
    }
})
floatingMenuBack.addEventListener('click',()=>{
    showMenuIcon();
})
floatingAccount.addEventListener('click',()=>{
    showFloatingAccount();
    if(menuButtons.style.display == 'flex'){
        showMenuIcon();
    }
})
floatingAccountMenuBack.addEventListener('click',()=>{
    showFloatingAccount();
})