CREATE DATABASE IF NOT EXISTS project;
USE project;

CREATE TABLE IF NOT EXISTS users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nickname VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    balance DECIMAL(10,2) DEFAULT 1000.00,
    created_account_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login_date DATETIME DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS commodities (
    commodity_id INT AUTO_INCREMENT PRIMARY KEY,
    commodity_name VARCHAR(100) NOT NULL,
    buy_price DECIMAL(10,2) NOT NULL,
    sell_price DECIMAL(10,2) NOT NULL
);

INSERT INTO commodities (commodity_name, buy_price, sell_price) VALUES 
    ('Diament', 5000.00, 4800.00),
    ('Szmaragd', 3000.00, 2800.00),
    ('Rubin', 2500.00, 2300.00),
    ('Ametyst', 1500.00, 1400.00),
    ('Topaz', 1200.00, 1100.00),
    ('Perła', 1000.00, 950.00),
    ('Złoto', 2000.00, 1900.00),
    ('Srebro', 800.00, 750.00);

CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    commodity_id INT NOT NULL,
    amount INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    id_user INT NOT NULL,
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    id_bought BOOLEAN NOT NULL,
    FOREIGN KEY (commodity_id) REFERENCES commodities(commodity_id),
    FOREIGN KEY (id_user) REFERENCES users(id_user)
);

