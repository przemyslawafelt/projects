<?php
session_start(); 

$host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "project";

$conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if (!$conn) {
    die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['email'], $_POST['password'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id_user'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['nickname'] = $user['nickname'];

            header("Location: dashboard.php");
            exit();
        } else {
            $error_message = "Nieprawidłowe hasło. Spróbuj ponownie.";
        }
    } else {
        $error_message = "Nie znaleziono użytkownika z podanym emailem.";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Gra przeglądarkowa o giełdzie minerałów">
    <meta name="keywords" content="Gra, Gra giełda minerałów, lichwiarz">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Lichwiarz - Logowanie</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="../css/style.css" type="text/css">
</head>
<body>
    <div class="wrapper">
    <nav class="logBar">
        <a href="index.php">
            <div class="introduce glassButton">
                <div class="introduce__logo">
                    <img src="../img/logo.png">
                </div>
                <div class="introduce__text">Lichwiarz.net</div>
            </div>
        </a>
        <div class="buttons">
            <a href="shop.php">
                <div class="buttons__button glassButton">Sklep</div>
            </a>
            <a href="dashboard.php">
                <div class="buttons__button glassButton">Dashboard</div>
            </a>
            <a href="#" target="_blank">
                <div class="buttons__button glassButton">Azbest</div>
            </a>
        </div>

        <div class="login">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php"><div class="login__button">Wyloguj</div></a>
            <?php else: ?>
                <a href="login.php"><div class="login__button login__button--green">Zaloguj</div></a>
                <a href="register.php"><div class="login__button">Rejestracja</div></a>
            <?php endif; ?>
        </div>    
    </nav>


        <div class="register__main">
            <form action="login.php" method="POST">
                <h1>Witaj, wpisz swoje dane aby się zalogować</h1>
                <?php if (!empty($error_message)) echo "<p style='color: red;'>$error_message</p>"; ?>
                <p>Email</p><input type="text" name="email" maxlength="50" required>
                <p>Hasło</p><input type="password" name="password" maxlength="30" required><br>
                <input type="submit" value="Zaloguj">
            </form>
        </div>
    </div>
</body>
</html>
