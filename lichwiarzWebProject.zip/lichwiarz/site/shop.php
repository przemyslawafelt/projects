<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "project";

$conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if (!$conn) {
    die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
}

$user_id = $_SESSION['user_id'];
$result = mysqli_query($conn, "SELECT balance FROM users WHERE id_user = $user_id");
$user = mysqli_fetch_assoc($result);
$balance = $user['balance'];

$owned_resources = [];
$resource_query = mysqli_query($conn, "
    SELECT c.commodity_id, c.commodity_name,
           COALESCE(SUM(CASE WHEN t.id_bought = 1 THEN t.amount ELSE 0 END), 0) - 
           COALESCE(SUM(CASE WHEN t.id_bought = 0 THEN t.amount ELSE 0 END), 0) AS total_owned
    FROM commodities c
    LEFT JOIN transactions t ON c.commodity_id = t.commodity_id AND t.id_user = $user_id
    GROUP BY c.commodity_id, c.commodity_name
");

while ($row = mysqli_fetch_assoc($resource_query)) {
    $owned_resources[$row['commodity_id']] = $row['total_owned'];
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $commodity_id = intval($_POST['commodity_id']);
    $amount = intval($_POST['amount']);
    $transaction_type = $_POST['transaction_type'];

    if ($amount > 0) {
        $commodity_result = mysqli_query($conn, "SELECT * FROM commodities WHERE commodity_id = $commodity_id");
        if ($commodity = mysqli_fetch_assoc($commodity_result)) {
            if ($transaction_type === "buy") {
                $total_cost = $commodity['buy_price'] * $amount;
                if ($balance >= $total_cost) {
                    mysqli_query($conn, "UPDATE users SET balance = balance - $total_cost WHERE id_user = $user_id");
                    mysqli_query($conn, "INSERT INTO transactions (commodity_id, amount, price, id_user, id_bought) 
                                         VALUES ($commodity_id, $amount, {$commodity['buy_price']}, $user_id, 1)");
                    header("Location: shop.php");
                    exit();
                } else {
                    $message = "Nie masz wystarczających środków!";
                }
            } elseif ($transaction_type === "sell") {
                $available = $owned_resources[$commodity_id] ?? 0;
                if ($available >= $amount) {
                    $total_earnings = $commodity['sell_price'] * $amount;
                    mysqli_query($conn, "UPDATE users SET balance = balance + $total_earnings WHERE id_user = $user_id");
                    mysqli_query($conn, "INSERT INTO transactions (commodity_id, amount, price, id_user, id_bought) 
                                         VALUES ($commodity_id, $amount, {$commodity['sell_price']}, $user_id, 0)");
                    header("Location: shop.php");
                    exit();
                } else {
                    $message = "Nie masz wystarczającej ilości surowca do sprzedaży!";
                }
            }
        }
    }
}
$commodities = mysqli_query($conn, "SELECT * FROM commodities");
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Gra przeglądarkowa o giełdzie minerałów">
    <meta name="keywords" content="Gra, Gra giełda minerałów, lichwiarz">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Lichwiarz - Sklep</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="../css/style.css" type="text/css">
    <link rel="stylesheet" href="../css/style_dashboard.css" type="text/css">
</head>
<body>
    <div class="wrapper">
        <nav class="logBar">
            <a href="index.php">
                <div class="introduce glassButton">
                    <div class="introduce__logo">
                        <img src="../img/logo.png">
                    </div>
                    <div class="introduce__text">Lichwiarz.net</div>
                </div>
            </a>
            <div class="buttons">
                <a href="shop.php">
                    <div class="buttons__button glassButton">Sklep</div>
                </a>
                <a href="dashboard.php">
                    <div class="buttons__button glassButton">Dashboard</div>
                </a>
                <a href="#" target="_blank">
                    <div class="buttons__button glassButton">Azbest</div>
                </a>
            </div>
            <div class="login">
                <a href="logout.php"><div class="login__button">Wyloguj</div></a>
            </div>    
        </nav>

        <main>
            <h2>Twoje saldo: <?php echo number_format($balance, 2); ?> zł</h2>

            <?php if (isset($message)) echo "<p style='color: green;'>$message</p>"; ?>

            <table border="1">
                <tr>
                    <th>Surowiec</th>
                    <th>Cena Kupna</th>
                    <th>Cena Sprzedaży</th>
                    <th>Posiadasz</th>
                    <th>Akcja</th>
                </tr>
                <?php while ($commodity = mysqli_fetch_assoc($commodities)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($commodity['commodity_name']); ?></td>
                        <td><?php echo number_format($commodity['buy_price'], 2); ?> zł</td>
                        <td><?php echo number_format($commodity['sell_price'], 2); ?> zł</td>
                        <td><?php echo $owned_resources[$commodity['commodity_id']] ?? 0; ?> szt.</td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="commodity_id" value="<?php echo $commodity['commodity_id']; ?>">
                                <input type="number" name="amount" min="1" required>
                                <button type="submit" name="transaction_type" value="buy">Kup</button>
                                <button type="submit" name="transaction_type" value="sell">Sprzedaj</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        </main>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>
