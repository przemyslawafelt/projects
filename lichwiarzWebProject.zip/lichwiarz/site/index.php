<?php
if (session_status() === PHP_SESSION_NONE){
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Gra przeglądarkowa o giełdzie minerałów">
    <meta name="keywords" content="Gra, Gra giełda minerałów, lichwiarz">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Lichwiarz</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="icon" href="./img/logo.png">
    <link rel="stylesheet" href="../css/style.css" type="text/css">
</head>
<body>
    <div class="menuBurger">
        <img class="floatingMenu" src="../img/menu.png">
        <img class="floatingMenuBack" src="../img/arrow.png">
    </div>
    <div class="loginMenuBurger">
        <img class="floatingAccount" src="../img/account.png">
        <img class="floatingAccountMenuBack" src="../img/arrow.png">
    </div>
    <div class="wrapper">
    
    <nav class="logBar">
        <a href="index.php">
            <div class="introduce glassButton">
                <div class="introduce__logo">
                    <img src="../img/logo.png">
                </div>
                <div class="introduce__text">Lichwiarz.net</div>
            </div>
        </a>
        <div class="buttons">
            <a href="shop.php">
                <div class="buttons__button glassButton">Sklep</div>
            </a>
            <a href="dashboard.php">
                <div class="buttons__button glassButton">Dashboard</div>
            </a>
            <a href="#" target="_blank">
                <div class="buttons__button glassButton">Azbest</div>
            </a>
        </div>

        <div class="login">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php"><div class="login__button">Wyloguj</div></a>
            <?php else: ?>
                <a href="login.php"><div class="login__button login__button--green">Zaloguj</div></a>
                <a href="register.php"><div class="login__button">Rejestracja</div></a>
            <?php endif; ?>
        </div>    
    </nav>


        <header class="banner">
            <div class="bannerInfo">
                    <h1 class="bannerInfo__header">Lichwiarz</h1>
                    <p class="bannerInfo__text">Twoja kopalnia minerałów</p>
            </div>
        </header>
        <main>

        </main>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>