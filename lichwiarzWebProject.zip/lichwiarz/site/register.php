<?php
$host = "localhost"; 
$db_user = "root";
$db_password = "";
$db_name = "project";

$conn = mysqli_connect($host, $db_user, $db_password, $db_name);

if (!$conn) {
    die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['email'], $_POST['nickname'], $_POST['password'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $nickname = mysqli_real_escape_string($conn, $_POST['nickname']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $starting_balance = 100000.00;

    if (empty($email) || empty($nickname) || empty($password)) {
        $message = '<p style="color: red; font-size: 20px;">Proszę wypełnić wszystkie pola formularza.</p>';
    } else {
        $email_check = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
        if (mysqli_num_rows($email_check) > 0) {
            $message = '<p style="color: red; font-size: 20px;">Email jest już zarejestrowany. Wybierz inny email.</p>';
        } else {
            $nickname_check = mysqli_query($conn, "SELECT * FROM users WHERE nickname = '$nickname'");
            if (mysqli_num_rows($nickname_check) > 0) {
                $message = '<p style="color: red; font-size: 20px;">Nickname jest już zajęty. Wybierz inny.</p>';
            } else {
                $sql = "INSERT INTO users (email, nickname, password, balance) VALUES ('$email', '$nickname', '$hashed_password', '$starting_balance')";

                if (mysqli_query($conn, $sql)) {
                    $message = '<p style="color: green; font-size: 20px;">Rejestracja zakończona sukcesem! Otrzymałeś 100000 kredytów.</p>';
                } else {
                    $message = '<p style="color: red; font-size: 20px;">Błąd podczas rejestracji: ' . mysqli_error($conn) . '</p>';
                }
            }
        }
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Gra przeglądarkowa o giełdzie minerałów">
    <meta name="keywords" content="Gra, Gra giełda minerałów, lichwiarz">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Lichwiarz - Rejestracja</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <link rel="icon" href="../img/logo.png">
    <link rel="stylesheet" href="../css/style.css" type="text/css">
</head>
<body style="background-color: #aaa">
    <div class="wrapper">
    <?php session_start(); ?>
    <nav class="logBar">
        <a href="index.php">
            <div class="introduce glassButton">
                <div class="introduce__logo">
                    <img src="../img/logo.png">
                </div>
                <div class="introduce__text">Lichwiarz.net</div>
            </div>
        </a>
        <div class="buttons">
            <a href="shop.php">
                <div class="buttons__button glassButton">Sklep</div>
            </a>
            <a href="dashboard.php">
                <div class="buttons__button glassButton">Dashboard</div>
            </a>
            <a href="#" target="_blank">
                <div class="buttons__button glassButton">Azbest</div>
            </a>
        </div>

        <div class="login">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php"><div class="login__button">Wyloguj</div></a>
            <?php else: ?>
                <a href="login.php"><div class="login__button login__button--green">Zaloguj</div></a>
                <a href="register.php"><div class="login__button">Rejestracja</div></a>
            <?php endif; ?>
        </div>    
    </nav>


        <div class="register__main">
            <form action="register.php" method="POST">
                <h1>Witaj, uzupełnij formularz, abyśmy mogli stworzyć konto dla ciebie</h1>
                <?= $message; ?>
                <p>Email</p><input type="email" name="email" maxlength="50" required>
                <p>Nickname</p><input type="text" name="nickname" maxlength="30" required>
                <p>Hasło</p><input type="password" name="password" maxlength="30" required><br>
                <input type="submit" value="Rejestruj">
            </form>
        </div>
    </div>
</body>
</html>
